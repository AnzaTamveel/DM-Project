#include <iostream>
using namespace std;

int main() {
    int n, m;
    cout << "Enter the number of vertices: ";
    cin >> n;
    cout << "Enter the number of edges: ";
    cin >> m;
    int inDegree[n] = {0}, outDegree[n] = {0};
    cout << "Enter the edges:\n";
    for(int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        outDegree[u]++;
        inDegree[v]++;
    }
    for(int i = 0; i < n; i++) {
        cout << "In-degree of vertex " << i << " is " << inDegree[i] << endl;
        cout << "Out-degree of vertex " << i << " is " << outDegree[i] << endl;
    }
    return 0;
}
