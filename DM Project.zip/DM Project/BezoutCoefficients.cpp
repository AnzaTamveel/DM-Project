#include <iostream>
using namespace std;
// Function to implement the Extended Euclidean Algorithm
void extendedEuclidean(int a, int b, int &s, int &t) {
    if (b==0) {
        s=1;
        t=0;
    } else {
        int s1,t1;
        extendedEuclidean(b,a%b,s1,t1);
        s=t1;
        t=s1-(a/b)*t1;
    }
}
int main() {
  int num1,num2;
  cout<<"Enter the first positive integer: ";
  cin>>num1;
  cout<<"Enter the second positive integer: ";
  cin>>num2;
  int s,t;
  extendedEuclidean(num1, num2, s, t);
  cout<<"The Bezout coefficients for"<<num1<<"and"<<num2<<"are:s="<<s<<",t="<<t<<endl;
  return 0;
}
