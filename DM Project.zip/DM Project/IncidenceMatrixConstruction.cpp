#include <iostream>

using namespace std;

const int MaxVertces = 100;  // Maximum number of vertices

// Function to construct an incidence matrix for an undirected graph
void constructIncidenceM(int edges[MaxVertces][2], int numEdges, int numVertices, int incidenceM[MaxVertces][MaxVertces]) {
    // Initialize the incidence matrix to zeros
    for (int i = 0; i < numVertices; ++i) {
        for (int j = 0; j < numEdges; ++j) {
            incidenceM[i][j] = 0;
        }
    }

    for (int i = 0; i < numEdges; ++i) {
        int u = edges[i][0];
        int v = edges[i][1];

        incidenceM[u][i] = 1;
        incidenceM[v][i] = 1;
    }
}

int main() {
    // Input the number of vertices and edges
    int numVertices, numEdges;

    cout << "Enter the number of vertices: ";
    cin >> numVertices;

    cout << "Enter the number of edges: ";
    cin >> numEdges;

    // Input the edges and their frequencies
    int edges[MaxVertces][2];
    cout << "Enter the edges (vertex pairs):" << endl;
    for (int i = 0; i < numEdges; ++i) {
        cin >> edges[i][0] >> edges[i][1];
    }

    // Construct the incidence matrix
    int incidenceM[MaxVertces][MaxVertces];
    constructIncidenceM(edges, numEdges, numVertices, incidenceM);

    // Display the incidence matrix
    cout << "Incidence Matrix:" << endl;
    for (int i = 0; i < numVertices; ++i) {
        for (int j = 0; j < numEdges; ++j) {
            cout << incidenceM[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
