#include <iostream>
using namespace std;
bool isPrime(int n)
{
    if (n <= 1)
    {
        return false;
    }
    if (n <= 3)
    {
        return true;
    }
    if (n % 2 == 0 || n % 3 == 0)
    {
        return false;
    }
    for (int i = 5; i * i <= n; i = i + 6)
        if (n % i == 0 || n % (i + 2) == 0)
            return false;
    return true;
}
int gcd(int a, int b)
{
    if (b == 0)
        return a;
    return gcd(b, a % b);
}
long power(long x, int y, int p)
{
    long res = 1;
    x = x % p;
    while (y > 0)
    {
        if (y & 1)
            res = (res * x) % p;
        y = y >> 1;
        x = (x * x) % p;
    }
    return res;
}
int main()
{
    long msg, p, q, e;
    cout << "Enter message: ";
    cin >> msg;
    cout << "Enter p: ";
    cin >> p;
    cout << "Enter q: ";
    cin >> q;
    cout << "Enter e: ";
    cin >> e;
    if (!isPrime(p) || !isPrime(q))
    {
        cout << "p and q should be prime numbers" << endl;
        return 0;
    }
    long n = p * q;
    long phi = (p - 1) * (q - 1);
    if (gcd(e, phi) != 1)
    {
        cout << "e should be relatively prime to (p - 1)(q - 1)" << endl;
        return 0;
    }
    cout << "Encrypted message is " << power(msg, e, n) << endl;
    return 0;
}
