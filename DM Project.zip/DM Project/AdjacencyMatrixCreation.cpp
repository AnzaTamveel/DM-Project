#include <iostream>
using namespace std;

int main() {
    int n, m;
    cout << "Enter the number of vertices: ";
    cin >> n;
    cout << "Enter the number of edges: ";
    cin >> m;
    int adjMatrix[n][n] = {0};
    cout << "Enter the edges: "<<endl;
    for(int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        adjMatrix[u][v]++;
        adjMatrix[v][u]++;
    }
    cout << "The adjacency matrix is: "<<endl;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            cout << adjMatrix[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}
