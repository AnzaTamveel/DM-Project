#include <iostream>
#include <cstring>
const int MAXN = 1000;
using namespace std;
bool isBipartite(int graph[][MAXN], int n, int start)
{
    int color[MAXN];
    memset(color, -1, sizeof(color));
    color[start] = 0;
    for (int u = 0; u < n; ++u)
        for (int v = 0; v < n; ++v)
            if (graph[u][v] && color[v] == -1)
                color[v] = 1 - color[u];
            else if (graph[u][v] && color[v] == color[u])
                return false;
    return true;
}
bool isBipartiteGraph(int graph[][MAXN], int n, int m, int edges[][2])
{
    for (int i = 0; i < m; ++i)
        if (!isBipartite(graph, n, edges[i][0]))
            return false;
    return true;
}
int main()
{
    int n, m;
    cin >> n >> m;
    int edges[MAXN][2];
    for (int i = 0; i < m; ++i)
        cin >> edges[i][0] >> edges[i][1];
    int graph[MAXN][MAXN];
    memset(graph, 0, sizeof(graph));
    for (int i = 0; i < m; ++i)
    {
        int u = edges[i][0];
        int v = edges[i][1];
        graph[u][v] = graph[v][u] = 1;
    }
    if (isBipartiteGraph(graph, n, m, edges))
    {
        cout << "The graph is bipartite." << endl;
    }
    else
    {
        cout << "The graph is not bipartite." << endl;
    }
    return 0;
}
