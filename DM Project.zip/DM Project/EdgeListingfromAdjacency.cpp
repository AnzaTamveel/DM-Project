#include <iostream>

using namespace std;

const int MaxV = 100; 

// Function to list edges and their frequencies from an adjacency matrix
void listEdgesFromadjM(int adjM[MaxV][MaxV], int NumVer) {
    cout << "Edges and their frequencies:" << endl;

    // Iterate through the upper triangular part of the matrix to avoid duplicates
    for (int i = 0; i < NumVer; ++i) {
        for (int j = i; j < NumVer; ++j) {
            int f = adjM[i][j];
            if (f > 0) {
                cout << "Edge " << i << " - " << j << ": " << f << " time." << endl;
            }
        }
    }
}

int main() {
    // Input the number of_vertices
    int NumVer;

    cout << "Enter the number of_vertices: ";
    cin >> NumVer;

    // Input the adjacency matrix
    int adjM[MaxV][MaxV] = {0};
    cout << "Enter the adjacency matrix:" << endl;
    for (int i = 0; i < NumVer; ++i) {
        for (int j = 0; j < NumVer; ++j) {
            cin >> adjM[i][j];
        }
    }

    // List edges and their frequencies
    listEdgesFromadjM(adjM, NumVer);

    return 0;
}
